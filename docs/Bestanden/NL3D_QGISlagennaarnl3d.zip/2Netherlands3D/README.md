# 2Netherlands3D — QGIS Plugin

Exporteer QGIS vectorlagen naar het **Netherlands3D (.nl3d)** formaat dat gebruikt wordt door [netherlands3d.eu](https://netherlands3d.eu).

## Wat doet de plugin?

- Laadt alle vectorlagen uit je QGIS project
- Laat je per laag kiezen of je die wilt exporteren, en als welk type:
  - **Punten** (`punten.geojson`)
  - **Lijnen** (`lijnen.geojson`)
  - **Vlakken** (`Vlakken.geojson`)
- Laat je per laag een kleur kiezen
- Reprojecteert automatisch naar **EPSG:28992 (RD New)**
- Bundelt alles in één `.nl3d` bestand dat je direct in Netherlands3D kunt openen

---

## Installatie

### Methode 1 — Via QGIS Plugin Manager (aanbevolen)

1. Pak de map `nl3d_export_plugin/` (of de `.zip`) op in je QGIS plugins map:
   - **Windows**: `%APPDATA%\QGIS\QGIS3\profiles\default\python\plugins\`
   - **macOS**: `~/Library/Application Support/QGIS/QGIS3/profiles/default/python/plugins/`
   - **Linux**: `~/.local/share/QGIS/QGIS3/profiles/default/python/plugins/`

2. Start QGIS (opnieuw) op.

3. Ga naar **Plugins → Plugins beheren en installeren**.

4. Zoek naar **2Netherlands3D** en activeer de plugin.

### Methode 2 — Handmatig via ZIP

1. Zipip de map `nl3d_export_plugin/` als `nl3d_export_plugin.zip`.
2. Ga in QGIS naar **Plugins → Plugins beheren en installeren → Installeren vanuit ZIP**.
3. Kies het ZIP-bestand en klik **Plugin installeren**.

---

## Gebruik

1. Laad je vectorlagen in QGIS (punten, lijnen of vlakken).
2. Klik op **Plugins → 2Netherlands3D → Exporteer naar .nl3d…**  
   (of gebruik het toolbar-icoontje).
3. In het dialoogvenster:
   - Vink de lagen aan die je wilt exporteren.
   - Stel per laag het exporttype in (Punten / Lijnen / Vlakken).
   - Kies een kleur per laag (optioneel).
   - Kies een uitvoerlocatie.
4. Klik **Exporteren**.
5. Open het `.nl3d` bestand in [Netherlands3D](https://netherlands3d.eu).

---

## Technische details

Het `.nl3d` bestand is een **ZIP-archief** met:

| Bestand | Beschrijving |
|---|---|
| `project.json` | Projectmetadata, laagboom, camera-instellingen |
| `punten.geojson` | Puntlagen (EPSG:28992) |
| `lijnen.geojson` | Lijnlagen (EPSG:28992) |
| `Vlakken.geojson` | Vlakkenlagen (EPSG:28992) |

Lagen met hetzelfde exporttype worden samengevoegd in één GeoJSON-bestand.  
Alle attributen van de bronlagen worden meegenomen als GeoJSON properties.

---

## Vereisten

- QGIS 3.16 of hoger
- Python 3.x (standaard meegeleverd met QGIS)

---

## Licentie

MIT License — vrij te gebruiken en aan te passen.
