# -*- coding: utf-8 -*-
"""
2Netherlands3D Export Plugin for QGIS
Exports QGIS project layers to the Netherlands3D .nl3d format.
"""


def classFactory(iface):
    from .plugin import NL3DExportPlugin
    return NL3DExportPlugin(iface)
