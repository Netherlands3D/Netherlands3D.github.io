# -*- coding: utf-8 -*-
"""
2Netherlands3D Export Dialog - met live kaartpreview
"""
import os
from qgis.PyQt.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QFileDialog, QTableWidget, QTableWidgetItem, QHeaderView,
    QComboBox, QCheckBox, QGroupBox, QProgressBar, QMessageBox,
    QLineEdit, QSizePolicy, QFrame, QWidget, QSplitter
)
from qgis.PyQt.QtCore import Qt, QSize, QTimer, QRectF, QPointF
from qgis.PyQt.QtGui import (
    QColor, QFont, QIcon, QPainter, QPen, QBrush,
    QPolygonF, QPainterPath
)
from qgis.core import (
    QgsProject, QgsWkbTypes, QgsCoordinateReferenceSystem,
    QgsCoordinateTransform, QgsRectangle
)

from .exporter import NL3DExporter

# --- Geometry type constants ---
GEOM_TYPE_LABELS = {
    'Point': 'Punten',
    'Line': 'Lijnen',
    'Polygon': 'Vlakken',
    'Unknown': 'Onbekend',
}

GEOM_TYPE_COLORS = {
    'Punten': '#EF6CFF80',
    'Lijnen': '#2B1EFF80',
    'Vlakken': '#55FFE180',
}

TARGET_CRS = QgsCoordinateReferenceSystem('EPSG:28992')


def get_layer_geometry_type(layer):
    wkb = layer.wkbType()
    flat = QgsWkbTypes.flatType(wkb)
    if flat in (QgsWkbTypes.Point, QgsWkbTypes.MultiPoint,
                QgsWkbTypes.PointZ, QgsWkbTypes.MultiPointZ):
        return 'Point'
    elif flat in (QgsWkbTypes.LineString, QgsWkbTypes.MultiLineString,
                  QgsWkbTypes.LineStringZ, QgsWkbTypes.MultiLineStringZ):
        return 'Line'
    elif flat in (QgsWkbTypes.Polygon, QgsWkbTypes.MultiPolygon,
                  QgsWkbTypes.PolygonZ, QgsWkbTypes.MultiPolygonZ):
        return 'Polygon'
    return 'Unknown'


# ---------------------------------------------------------------------------
# Live map preview widget
# ---------------------------------------------------------------------------

class MapPreviewWidget(QWidget):
    """
    Renders a live 2D preview of all checked layers using QPainter.
    Automatically reprojects to EPSG:28992 for a consistent coordinate space.
    """

    def __init__(self, parent=None):
        super().__init__(parent)
        self._layers_data = []
        self._bbox = None
        self.setMinimumSize(240, 240)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.setToolTip('Live voorvertoning van de te exporteren lagen')

    def update_layers(self, export_rows):
        """
        Rebuild geometry data from the given export rows.
        export_rows: list of (QgsVectorLayer, export_as_label, color_hex)
        """
        self._layers_data = []
        combined_bbox = None

        for layer, export_as, color_hex in export_rows:
            geom_type = get_layer_geometry_type(layer)
            if geom_type == 'Unknown':
                continue

            source_crs = layer.crs()
            needs_transform = source_crs != TARGET_CRS
            transform = QgsCoordinateTransform(source_crs, TARGET_CRS, QgsProject.instance())

            geometries = []
            count = 0
            limit = 2000
            for feature in layer.getFeatures():
                if count >= limit:
                    break
                geom = feature.geometry()
                if geom.isNull():
                    continue
                if needs_transform:
                    try:
                        geom.transform(transform)
                    except Exception:
                        continue
                geometries.append((geom_type, geom))
                count += 1

            if not geometries:
                continue

            # Extend overall bounding box
            try:
                ext = layer.extent()
                if not ext.isNull() and not ext.isEmpty():
                    if needs_transform:
                        ext = transform.transformBoundingBox(ext)
                    if combined_bbox is None:
                        combined_bbox = QgsRectangle(ext)
                    else:
                        combined_bbox.combineExtentWith(ext)
            except Exception:
                pass

            self._layers_data.append((geom_type, color_hex, geometries))

        self._bbox = combined_bbox
        self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)

        w = self.width()
        h = self.height()

        # Dark map background
        painter.fillRect(0, 0, w, h, QColor('#1e2533'))

        # Subtle grid
        painter.setPen(QPen(QColor('#263045'), 1))
        step = 40
        for x in range(0, w, step):
            painter.drawLine(x, 0, x, h)
        for y in range(0, h, step):
            painter.drawLine(0, y, w, y)

        # Border
        painter.setPen(QPen(QColor('#3a4a6b'), 1))
        painter.drawRect(0, 0, w - 1, h - 1)

        if not self._layers_data or self._bbox is None or self._bbox.isNull():
            painter.setPen(QColor('#5a6a8a'))
            fnt = QFont()
            fnt.setPointSize(9)
            painter.setFont(fnt)
            painter.drawText(
                QRectF(0, 0, w, h), Qt.AlignCenter,
                'Selecteer lagen om\neen voorvertoning te zien'
            )
            painter.end()
            return

        # World → screen transform
        pad = 28
        bw = max(self._bbox.width(), 1.0)
        bh = max(self._bbox.height(), 1.0)
        scale = min((w - 2 * pad) / bw, (h - 2 * pad) / bh)
        ox = (w - bw * scale) / 2
        oy = (h - bh * scale) / 2
        bx = self._bbox.xMinimum()
        by = self._bbox.yMinimum()

        def to_screen(rx, ry):
            sx = ox + (rx - bx) * scale
            sy = h - (oy + (ry - by) * scale)   # flip Y
            return QPointF(sx, sy)

        # Draw layers
        for geom_type, color_hex, geometries in self._layers_data:
            fill_color = QColor(color_hex[:7])
            alpha = int(color_hex[7:9], 16) if len(color_hex) >= 9 else 180
            fill_color.setAlpha(alpha)
            stroke_color = QColor(color_hex[:7])
            stroke_color.setAlpha(min(255, alpha + 60))
            for gtype, geom in geometries:
                self._draw_geometry(painter, geom, gtype, fill_color, stroke_color, to_screen)

        # Compass rose
        self._draw_compass(painter, w - 26, 26, 13)

        # Feature count badge
        count = sum(len(g[2]) for g in self._layers_data)
        badge = f'{count} objecten'
        fnt2 = QFont()
        fnt2.setPointSize(7)
        painter.setFont(fnt2)
        painter.fillRect(4, h - 18, 78, 14, QColor(0, 0, 0, 120))
        painter.setPen(QColor('#ccddff'))
        painter.drawText(6, h - 6, badge)

        painter.end()

    def _draw_geometry(self, painter, geom, geom_type, fill_color, stroke_color, to_screen):
        if geom_type == 'Point':
            pt = geom.asPoint()
            sp = to_screen(pt.x(), pt.y())
            painter.setPen(QPen(stroke_color, 1.5))
            painter.setBrush(QBrush(fill_color))
            painter.drawEllipse(sp, 4, 4)

        elif geom_type == 'Line':
            painter.setPen(QPen(fill_color, 1.8))
            painter.setBrush(Qt.NoBrush)
            wkb_type = geom.wkbType()
            parts = geom.asMultiPolyline() if QgsWkbTypes.isMultiType(wkb_type) else [geom.asPolyline()]
            for part in parts:
                if len(part) < 2:
                    continue
                path = QPainterPath()
                path.moveTo(to_screen(part[0].x(), part[0].y()))
                for pt in part[1:]:
                    path.lineTo(to_screen(pt.x(), pt.y()))
                painter.drawPath(path)

        elif geom_type == 'Polygon':
            painter.setPen(QPen(stroke_color, 0.8))
            painter.setBrush(QBrush(fill_color))
            wkb_type = geom.wkbType()
            parts = geom.asMultiPolygon() if QgsWkbTypes.isMultiType(wkb_type) else [geom.asPolygon()]
            for part in parts:
                path = QPainterPath()
                for ring in part:
                    if not ring:
                        continue
                    path.moveTo(to_screen(ring[0].x(), ring[0].y()))
                    for pt in ring[1:]:
                        path.lineTo(to_screen(pt.x(), pt.y()))
                    path.closeSubpath()
                painter.drawPath(path)

    def _draw_compass(self, painter, cx, cy, r):
        # North (white)
        painter.setPen(Qt.NoPen)
        painter.setBrush(QBrush(QColor('#ffffff')))
        north = QPolygonF([
            QPointF(cx, cy - r),
            QPointF(cx - r * 0.35, cy + r * 0.4),
            QPointF(cx, cy),
        ])
        painter.drawPolygon(north)
        # South (grey)
        painter.setBrush(QBrush(QColor('#5a6a8a')))
        south = QPolygonF([
            QPointF(cx, cy + r),
            QPointF(cx + r * 0.35, cy - r * 0.4),
            QPointF(cx, cy),
        ])
        painter.drawPolygon(south)
        # N label
        fnt = QFont()
        fnt.setPointSize(6)
        fnt.setBold(True)
        painter.setFont(fnt)
        painter.setPen(QColor('#ffffff'))
        painter.drawText(QRectF(cx - 6, cy - r - 11, 12, 10), Qt.AlignCenter, 'N')


# ---------------------------------------------------------------------------
# Legend widget
# ---------------------------------------------------------------------------

class LegendWidget(QWidget):
    """Shows a small legend below the map preview."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self._entries = []
        self.setFixedHeight(100)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)

    def update_entries(self, entries):
        self._entries = entries
        self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        painter.fillRect(0, 0, self.width(), self.height(), QColor('#f5f7fa'))
        painter.setPen(QPen(QColor('#dde'), 1))
        painter.drawRect(0, 0, self.width() - 1, self.height() - 1)

        if not self._entries:
            fnt = QFont()
            fnt.setPointSize(8)
            painter.setFont(fnt)
            painter.setPen(QColor('#aaa'))
            painter.drawText(QRectF(0, 0, self.width(), self.height()),
                             Qt.AlignCenter, 'Geen lagen geselecteerd')
            painter.end()
            return

        x, y = 8, 8
        row_h = 18
        sw = 12
        fnt = QFont()
        fnt.setPointSize(8)
        painter.setFont(fnt)
        fm = painter.fontMetrics()
        max_w = self.width() - 30

        for name, export_as, color_hex in self._entries[:5]:
            fill = QColor(color_hex[:7])
            if len(color_hex) >= 9:
                fill.setAlpha(int(color_hex[7:9], 16))
            stroke = QColor(color_hex[:7])
            painter.setBrush(QBrush(fill))
            painter.setPen(QPen(stroke, 0.8))
            painter.drawRoundedRect(x, y + (row_h - sw) // 2, sw, sw, 2, 2)

            painter.setPen(QColor('#333'))
            label = f'{name}  \u2192  {export_as}'
            if fm.width(label) > max_w:
                label = label[:int(max_w / fm.averageCharWidth())] + '…'
            painter.drawText(x + sw + 6, y + row_h - 4, label)
            y += row_h

        if len(self._entries) > 5:
            painter.setPen(QColor('#888'))
            painter.drawText(x, y + row_h - 4, f'… en {len(self._entries) - 5} meer')

        painter.end()


# ---------------------------------------------------------------------------
# Color button
# ---------------------------------------------------------------------------

class ColorButton(QPushButton):
    def __init__(self, initial_hex='#569FE3FF', on_change=None, parent=None):
        super().__init__(parent)
        self.color_hex = initial_hex
        self._on_change = on_change
        # Vaste objectnaam zodat de stylesheet-selector alleen déze knop treft
        # en niet cascadeert naar knoppen in de QColorDialog (OK / Annuleren).
        self.setObjectName('NL3DColorButton')
        self._update_style()
        self.setFixedSize(QSize(56, 24))
        self.clicked.connect(self._pick_color)

    def _update_style(self):
        rgb = self.color_hex[:7]
        # Gebruik #objectnaam-selector: stijl geldt alleen voor deze knop,
        # niet voor QPushButton-children van de kleurkiezer-dialog.
        self.setStyleSheet(
            f'QPushButton#NL3DColorButton {{ background-color: {rgb}; border: 1px solid #888; border-radius: 3px; }}'
        )

    def _pick_color(self):
        from qgis.PyQt.QtWidgets import QColorDialog
        current = QColor(self.color_hex[:7])
        if len(self.color_hex) >= 9:
            current.setAlpha(int(self.color_hex[7:9], 16))
        chosen = QColorDialog.getColor(current, self, 'Kies kleur', QColorDialog.ShowAlphaChannel)
        if chosen.isValid():
            r, g, b, a = chosen.red(), chosen.green(), chosen.blue(), chosen.alpha()
            self.color_hex = f'#{r:02X}{g:02X}{b:02X}{a:02X}'
            self._update_style()
            if self._on_change:
                self._on_change()


# ---------------------------------------------------------------------------
# Layer table
# ---------------------------------------------------------------------------

class LayerTableWidget(QTableWidget):
    COL_INCLUDE = 0
    COL_LAYER_NAME = 1
    COL_GEOM_TYPE = 2
    COL_EXPORT_AS = 3
    COL_COLOR = 4
    HEADERS = ['', 'Laagnaam', 'Type', 'Exporteren als', 'Kleur']

    def __init__(self, on_change=None, parent=None):
        super().__init__(0, 5, parent)
        self._on_change = on_change
        self._setup_headers()
        self.layers = []

    def _setup_headers(self):
        self.setHorizontalHeaderLabels(self.HEADERS)
        hh = self.horizontalHeader()
        hh.setSectionResizeMode(self.COL_INCLUDE, QHeaderView.Fixed)
        hh.setSectionResizeMode(self.COL_LAYER_NAME, QHeaderView.Stretch)
        hh.setSectionResizeMode(self.COL_GEOM_TYPE, QHeaderView.ResizeToContents)
        hh.setSectionResizeMode(self.COL_EXPORT_AS, QHeaderView.ResizeToContents)
        hh.setSectionResizeMode(self.COL_COLOR, QHeaderView.Fixed)
        self.setColumnWidth(self.COL_INCLUDE, 32)
        self.setColumnWidth(self.COL_COLOR, 64)
        self.verticalHeader().setVisible(False)
        self.setAlternatingRowColors(True)
        self.setSelectionBehavior(QTableWidget.SelectRows)
        self.setEditTriggers(QTableWidget.NoEditTriggers)
        self.setShowGrid(False)

    def populate(self, layers):
        self.layers = layers
        self.setRowCount(0)
        for layer in layers:
            geom_type = get_layer_geometry_type(layer)
            if geom_type == 'Unknown':
                continue

            row = self.rowCount()
            self.insertRow(row)
            self.setRowHeight(row, 30)

            # Checkbox
            cb = QCheckBox()
            cb.setChecked(True)
            cb.stateChanged.connect(lambda _: self._on_change() if self._on_change else None)
            cb_widget = QWidget()
            cb_layout = QHBoxLayout(cb_widget)
            cb_layout.addWidget(cb)
            cb_layout.setAlignment(Qt.AlignCenter)
            cb_layout.setContentsMargins(0, 0, 0, 0)
            self.setCellWidget(row, self.COL_INCLUDE, cb_widget)

            # Layer name
            name_item = QTableWidgetItem(layer.name())
            name_item.setData(Qt.UserRole, layer.id())
            self.setItem(row, self.COL_LAYER_NAME, name_item)

            # Geometry type
            geom_label = GEOM_TYPE_LABELS.get(geom_type, 'Onbekend')
            geom_item = QTableWidgetItem(geom_label)
            geom_item.setTextAlignment(Qt.AlignCenter)
            self.setItem(row, self.COL_GEOM_TYPE, geom_item)

            # Export-as combo
            combo = QComboBox()
            for option in ['Punten', 'Lijnen', 'Vlakken']:
                combo.addItem(option)
            idx = combo.findText(geom_label)
            if idx >= 0:
                combo.setCurrentIndex(idx)
            combo.currentIndexChanged.connect(lambda _: self._on_change() if self._on_change else None)
            self.setCellWidget(row, self.COL_EXPORT_AS, combo)

            # Color button
            default_color = GEOM_TYPE_COLORS.get(geom_label, '#569FE3FF')
            color_btn = ColorButton(default_color, on_change=self._on_change)
            self.setCellWidget(row, self.COL_COLOR, color_btn)

    def get_export_rows(self):
        result = []
        for row in range(self.rowCount()):
            cb_widget = self.cellWidget(row, self.COL_INCLUDE)
            cb = cb_widget.findChild(QCheckBox)
            if cb and cb.isChecked():
                layer_id = self.item(row, self.COL_LAYER_NAME).data(Qt.UserRole)
                combo = self.cellWidget(row, self.COL_EXPORT_AS)
                export_as = combo.currentText()
                color_btn = self.cellWidget(row, self.COL_COLOR)
                result.append((layer_id, export_as, color_btn.color_hex))
        return result


# ---------------------------------------------------------------------------
# Main dialog
# ---------------------------------------------------------------------------

class NL3DExportDialog(QDialog):

    def __init__(self, iface, parent=None):
        super().__init__(parent)
        self.iface = iface
        self.setWindowTitle('Exporteer naar Netherlands3D (.nl3d)')
        self.setMinimumWidth(960)
        self.setMinimumHeight(580)
        self._debounce = QTimer()
        self._debounce.setSingleShot(True)
        self._debounce.timeout.connect(self._refresh_preview)
        self._build_ui()
        self._load_layers()

    def _build_ui(self):
        root = QVBoxLayout(self)
        root.setSpacing(10)
        root.setContentsMargins(14, 14, 14, 14)

        # Header
        title = QLabel('Exporteer naar Netherlands3D (.nl3d)')
        fnt = QFont()
        fnt.setPointSize(12)
        fnt.setBold(True)
        title.setFont(fnt)
        root.addWidget(title)

        subtitle = QLabel(
            'Selecteer lagen, stel het exporttype en de kleur in. '
            'De kaartpreview rechts toont realtime wat er geëxporteerd wordt.'
        )
        subtitle.setWordWrap(True)
        subtitle.setStyleSheet('color: #666; margin-bottom: 2px;')
        root.addWidget(subtitle)

        sep = QFrame()
        sep.setFrameShape(QFrame.HLine)
        sep.setFrameShadow(QFrame.Sunken)
        root.addWidget(sep)

        # Splitter: left table | right preview
        splitter = QSplitter(Qt.Horizontal)
        splitter.setHandleWidth(8)

        # ---- Left panel ----
        left = QWidget()
        left_l = QVBoxLayout(left)
        left_l.setContentsMargins(0, 0, 6, 0)
        left_l.setSpacing(8)

        layers_group = QGroupBox('Lagen')
        layers_inner = QVBoxLayout(layers_group)
        layers_inner.setSpacing(6)

        self.layer_table = LayerTableWidget(on_change=self._schedule_refresh)
        self.layer_table.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        layers_inner.addWidget(self.layer_table)

        sel_row = QHBoxLayout()
        btn_all = QPushButton('Alles selecteren')
        btn_all.setFixedWidth(130)
        btn_all.clicked.connect(self._select_all)
        btn_none = QPushButton('Niets selecteren')
        btn_none.setFixedWidth(130)
        btn_none.clicked.connect(self._deselect_all)
        sel_row.addWidget(btn_all)
        sel_row.addWidget(btn_none)
        sel_row.addStretch()
        layers_inner.addLayout(sel_row)
        left_l.addWidget(layers_group)

        out_group = QGroupBox('Uitvoerbestand')
        out_l = QHBoxLayout(out_group)
        self.output_edit = QLineEdit()
        self.output_edit.setPlaceholderText('Kies locatie voor het .nl3d bestand…')
        out_l.addWidget(self.output_edit)
        browse_btn = QPushButton('Bladeren…')
        browse_btn.setFixedWidth(90)
        browse_btn.clicked.connect(self._browse_output)
        out_l.addWidget(browse_btn)
        left_l.addWidget(out_group)

        splitter.addWidget(left)

        # ---- Right panel: preview ----
        right = QWidget()
        right_l = QVBoxLayout(right)
        right_l.setContentsMargins(6, 0, 0, 0)
        right_l.setSpacing(4)

        preview_lbl = QLabel('Voorvertoning')
        fnt2 = QFont()
        fnt2.setBold(True)
        preview_lbl.setFont(fnt2)
        right_l.addWidget(preview_lbl)

        self.map_preview = MapPreviewWidget()
        right_l.addWidget(self.map_preview, stretch=1)

        self.legend = LegendWidget()
        right_l.addWidget(self.legend)

        splitter.addWidget(right)
        splitter.setSizes([580, 360])
        root.addWidget(splitter, stretch=1)

        # Progress
        self.progress_bar = QProgressBar()
        self.progress_bar.setVisible(False)
        root.addWidget(self.progress_bar)

        self.status_label = QLabel('')
        self.status_label.setStyleSheet('color: #444; font-style: italic;')
        self.status_label.setVisible(False)
        root.addWidget(self.status_label)

        # Buttons
        btn_row = QHBoxLayout()
        btn_row.addStretch()
        self.cancel_btn = QPushButton('Annuleren')
        self.cancel_btn.setFixedWidth(100)
        self.cancel_btn.clicked.connect(self.reject)
        btn_row.addWidget(self.cancel_btn)

        self.export_btn = QPushButton('Exporteren')
        self.export_btn.setFixedWidth(120)
        self.export_btn.setDefault(True)
        self.export_btn.setStyleSheet(
            'QPushButton { background-color: #1a73e8; color: white; '
            'border-radius: 4px; padding: 6px 14px; font-weight: bold; }'
            'QPushButton:hover { background-color: #1558b0; }'
            'QPushButton:disabled { background-color: #aaa; }'
        )
        self.export_btn.clicked.connect(self._do_export)
        btn_row.addWidget(self.export_btn)
        root.addLayout(btn_row)

    def _load_layers(self):
        layers = list(QgsProject.instance().mapLayers().values())
        vector_layers = [l for l in layers if l.type() == l.VectorLayer]
        self.layer_table.populate(vector_layers)
        self._refresh_preview()

    def _schedule_refresh(self):
        self._debounce.start(150)

    def _refresh_preview(self):
        rows = self.layer_table.get_export_rows()
        project = QgsProject.instance()
        resolved = []
        legend_entries = []
        for layer_id, export_as, color_hex in rows:
            layer = project.mapLayer(layer_id)
            if layer:
                resolved.append((layer, export_as, color_hex))
                legend_entries.append((layer.name(), export_as, color_hex))
        self.map_preview.update_layers(resolved)
        self.legend.update_entries(legend_entries)

    def _select_all(self):
        for row in range(self.layer_table.rowCount()):
            w = self.layer_table.cellWidget(row, LayerTableWidget.COL_INCLUDE)
            cb = w.findChild(QCheckBox)
            if cb:
                cb.setChecked(True)

    def _deselect_all(self):
        for row in range(self.layer_table.rowCount()):
            w = self.layer_table.cellWidget(row, LayerTableWidget.COL_INCLUDE)
            cb = w.findChild(QCheckBox)
            if cb:
                cb.setChecked(False)

    def _browse_output(self):
        path, _ = QFileDialog.getSaveFileName(
            self, 'Sla .nl3d bestand op',
            QgsProject.instance().homePath() or os.path.expanduser('~'),
            'Netherlands3D bestanden (*.nl3d);;Alle bestanden (*)'
        )
        if path:
            if not path.lower().endswith('.nl3d'):
                path += '.nl3d'
            self.output_edit.setText(path)

    def _do_export(self):
        rows = self.layer_table.get_export_rows()
        if not rows:
            QMessageBox.warning(self, '2Netherlands3D Export', 'Selecteer minimaal één laag om te exporteren.')
            return

        output_path = self.output_edit.text().strip()
        if not output_path:
            QMessageBox.warning(self, '2Netherlands3D Export', 'Kies een uitvoerlocatie voor het .nl3d bestand.')
            return
        if not output_path.lower().endswith('.nl3d'):
            output_path += '.nl3d'

        project = QgsProject.instance()
        export_items = []
        for layer_id, export_as, color_hex in rows:
            layer = project.mapLayer(layer_id)
            if layer:
                export_items.append((layer, export_as, color_hex))

        if not export_items:
            QMessageBox.warning(self, '2Netherlands3D Export', 'Geen geldige lagen gevonden.')
            return

        self.export_btn.setEnabled(False)
        self.cancel_btn.setEnabled(False)
        self.progress_bar.setVisible(True)
        self.status_label.setVisible(True)
        self.progress_bar.setMaximum(len(export_items) + 1)
        self.progress_bar.setValue(0)

        try:
            exporter = NL3DExporter()
            exporter.progress_updated.connect(self._on_progress)
            exporter.export(export_items, output_path)
            self.progress_bar.setValue(self.progress_bar.maximum())
            QMessageBox.information(
                self, '2Netherlands3D Export — Klaar',
                f'Export succesvol!\n\nBestand opgeslagen als:\n{output_path}'
            )
            self.accept()
        except Exception as e:
            QMessageBox.critical(
                self, '2Netherlands3D Export — Fout',
                f'Er is een fout opgetreden tijdens de export:\n\n{str(e)}'
            )
        finally:
            self.export_btn.setEnabled(True)
            self.cancel_btn.setEnabled(True)

    def _on_progress(self, value, message):
        self.progress_bar.setValue(value)
        self.status_label.setText(message)
        from qgis.PyQt.QtWidgets import QApplication
        QApplication.processEvents()
