# -*- coding: utf-8 -*-
"""
NL3D Exporter - Core logic for building the .nl3d file.

The .nl3d format is a ZIP archive containing:
  - project.json     : Project metadata and layer tree
  - Vlakken.geojson  : Polygon features
  - punten.geojson   : Point features
  - lijnen.geojson   : Line features

All GeoJSON files use CRS EPSG:28992 (RD New / Amersfoort).
"""
import os
import json
import uuid
import zipfile
import tempfile
from datetime import datetime

from qgis.PyQt.QtCore import QObject, pyqtSignal
from qgis.core import (
    QgsCoordinateReferenceSystem,
    QgsCoordinateTransform,
    QgsProject,
    QgsWkbTypes,
    QgsVectorFileWriter,
    QgsVectorLayer,
    QgsFeatureRequest,
)

# Target CRS: Dutch RD New
CRS_RD = QgsCoordinateReferenceSystem('EPSG:28992')

# Mapping from Dutch export label to internal key and file name
EXPORT_TYPE_MAP = {
    'Punten': {
        'filename': 'punten.geojson',
        'geojson_name': 'punten',
        'layer_name_prefix': 'GeoJsonPointLayer',
        'prefab_child': '267c8f33152cac142b8e40a7bdc54523',
        'prefab_parent': 'e46381d2665c69245b2475c986f6d0c4',
        'default_color': '#EF6CFF80',
    },
    'Lijnen': {
        'filename': 'lijnen.geojson',
        'geojson_name': 'lijnen',
        'layer_name_prefix': 'GeoJsonLineLayer',
        'prefab_child': '1efd25daf167bd74bafd6eea4aeda576',
        'prefab_parent': 'e46381d2665c69245b2475c986f6d0c4',
        'default_color': '#2B1EFF80',
    },
    'Vlakken': {
        'filename': 'Vlakken.geojson',
        'geojson_name': 'Vlakken',
        'layer_name_prefix': 'GeoJsonPolygonLayer',
        'prefab_child': '509ce6cf579d6ed4b946913dff7eaed4',
        'prefab_parent': 'e46381d2665c69245b2475c986f6d0c4',
        'default_color': '#55FFE180',
    },
}

# Default functionalities block from the template
DEFAULT_FUNCTIONALITIES = [
    {"Id": "terrein", "IsEnabled": True},
    {"Id": "gebouwen", "IsEnabled": True},
    {"Id": "bomen-en-bospercelen", "IsEnabled": True},
    {"Id": "straatnamen", "IsEnabled": False},
    {"Id": "buurtnamen", "IsEnabled": False},
    {"Id": "wijknamen", "IsEnabled": False},
    {"Id": "gebouw-informatie", "IsEnabled": True},
    {"Id": "downloaden-3d-gebied", "IsEnabled": True},
    {"Id": "maak-screenshots", "IsEnabled": True},
    {"Id": "3d-modellen-toevoegen", "IsEnabled": True},
    {"Id": "indicatoren", "IsEnabled": False},
    {"Id": "gebouwen-kleuren", "IsEnabled": True},
    {"Id": "objectenbibliotheek", "IsEnabled": True},
    {"Id": "minimap", "IsEnabled": True},
    {"Id": "3d-tiles", "IsEnabled": True},
    {"Id": "google-realitymesh", "IsEnabled": True},
    {"Id": "zonnestand-simuleren", "IsEnabled": True},
    {"Id": "urbanreleaf", "IsEnabled": True},
    {"Id": "debug-info", "IsEnabled": False},
    {"Id": "first-person-viewer", "IsEnabled": False},
]

# Default base layers always included in the project.json
DEFAULT_BASE_LAYERS = [
    {
        "UUID": str(uuid.uuid4()),
        "name": "Bomen",
        "activeSelf": True,
        "color": "#569FE3FF",
        "children": [],
        "layerProperties": [
            {
                "$type": "Netherlands3D.Twin.Layers.Properties.MaskingLayerPropertyData, eu.netherlands3d.twin",
                "styleName": "default",
                "metadata": {"name": None},
                "stylingRules": {
                    "default": {
                        "name": "default",
                        "symbolizer": {"properties": {"mask-layer-mask": "111111111111111111111111"}},
                        "selector": ["boolean", True]
                    }
                }
            }
        ],
        "prefabId": "6915dd70276474a0688a5fb1a9c248c0"
    },
    {
        "UUID": str(uuid.uuid4()),
        "name": "Bossen",
        "activeSelf": True,
        "color": "#569FE3FF",
        "children": [],
        "layerProperties": [
            {
                "$type": "Netherlands3D.Twin.Layers.Properties.MaskingLayerPropertyData, eu.netherlands3d.twin",
                "styleName": "default",
                "metadata": {"name": None},
                "stylingRules": {
                    "default": {
                        "name": "default",
                        "symbolizer": {"properties": {"mask-layer-mask": "111111111111111111111111"}},
                        "selector": ["boolean", True]
                    }
                }
            }
        ],
        "prefabId": "65e87ace5e7c94c2dba27317474f1179"
    },
    {
        "UUID": str(uuid.uuid4()),
        "name": "Gebouwen",
        "activeSelf": True,
        "color": "#569FE3FF",
        "children": [],
        "layerProperties": [
            {
                "$type": "https://netherlands3d.eu/schemas/projects/layers/properties/HiddenObjectsData",
                "styleName": "default",
                "metadata": {"name": None},
                "stylingRules": {
                    "default": {
                        "name": "default",
                        "symbolizer": {"properties": {}},
                        "selector": ["boolean", True]
                    }
                }
            },
            {
                "$type": "Netherlands3D.Twin.Layers.Properties.MaskingLayerPropertyData, eu.netherlands3d.twin",
                "styleName": "default",
                "metadata": {"name": None},
                "stylingRules": {
                    "default": {
                        "name": "default",
                        "symbolizer": {"properties": {"mask-layer-mask": "101111111111111111111111"}},
                        "selector": ["boolean", True]
                    }
                }
            }
        ],
        "prefabId": "cc9d0f9a5a1724c9695a1bef5ecccaec"
    },
    {
        "UUID": str(uuid.uuid4()),
        "name": "Maaiveld",
        "activeSelf": True,
        "color": "#569FE3FF",
        "children": [],
        "layerProperties": [
            {
                "$type": "https://netherlands3d.eu/schemas/projects/layers/properties/LayerFeatureColorData",
                "styleName": "default",
                "metadata": {"name": None},
                "stylingRules": {
                    "default": {
                        "name": "default",
                        "symbolizer": {"properties": {}},
                        "selector": ["boolean", True]
                    }
                }
            },
            {
                "$type": "Netherlands3D.Twin.Layers.Properties.MaskingLayerPropertyData, eu.netherlands3d.twin",
                "styleName": "default",
                "metadata": {"name": None},
                "stylingRules": {
                    "default": {
                        "name": "default",
                        "symbolizer": {"properties": {"mask-layer-mask": "111111111111111111111111"}},
                        "selector": ["boolean", True]
                    }
                }
            }
        ],
        "prefabId": "2e71ce721dd3e41c194c6fb05ad10520"
    },
    {
        "UUID": str(uuid.uuid4()),
        "name": "Ondergrond",
        "activeSelf": True,
        "color": "#569FE3FF",
        "children": [],
        "layerProperties": [
            {
                "$type": "https://netherlands3d.eu/schemas/projects/layers/properties/Transform",
                "position": {
                    "coordinateSystem": 2,
                    "extraLongitudeRotation": 0.0,
                    "extraLattitudeRotation": 0.0,
                    "value1": 154992.8671875,
                    "value2": 462973.40127563477,
                    "value3": -200.00323486328125
                },
                "eulerRotation": {"x": 0.0, "y": 0.0, "z": 0.0},
                "localScale": {"x": 10000.0, "y": 10000.0, "z": 10000.0},
                "scaleUnitCharacter": "%"
            },
            {
                "$type": "https://netherlands3d.eu/schemas/projects/layers/properties/Color",
                "styleName": "default",
                "metadata": {"name": None},
                "stylingRules": {
                    "default": {
                        "name": "default",
                        "symbolizer": {"properties": {}},
                        "selector": ["boolean", True]
                    }
                }
            },
            {
                "$type": "https://netherlands3d.eu/schemas/projects/layers/properties/TransformLock",
                "positionAxes": 1,
                "rotationAxes": 0,
                "scaleAxes": 0
            },
            {
                "$type": "Netherlands3D.Twin.Layers.Properties.MaskingLayerPropertyData, eu.netherlands3d.twin",
                "styleName": "default",
                "metadata": {"name": None},
                "stylingRules": {
                    "default": {
                        "name": "default",
                        "symbolizer": {"properties": {}},
                        "selector": ["boolean", True]
                    }
                }
            }
        ],
        "prefabId": "f60b3c7f11823a9ce86527101bac825b"
    },
]


def _make_color_layer_property(color_hex):
    return {
        "$type": "https://netherlands3d.eu/schemas/projects/layers/properties/Color",
        "styleName": "default",
        "metadata": {"name": None},
        "stylingRules": {
            "default": {
                "name": "default",
                "symbolizer": {
                    "properties": {
                        "stroke-color": color_hex,
                        "fill-color": color_hex
                    }
                },
                "selector": None
            }
        }
    }


def _make_color_layer_property_empty(color_hex):
    """Parent layer color property (empty symbolizer properties)."""
    return {
        "$type": "https://netherlands3d.eu/schemas/projects/layers/properties/Color",
        "styleName": "default",
        "metadata": {"name": None},
        "stylingRules": {
            "default": {
                "name": "default",
                "symbolizer": {"properties": {}},
                "selector": None
            }
        }
    }


def _build_layer_node(layer_name, export_type_key, color_hex, filename):
    """Build the layer tree node for project.json for a single exported layer."""
    meta = EXPORT_TYPE_MAP[export_type_key]
    ref = f'project:///{filename}'

    child_node = {
        "UUID": str(uuid.uuid4()),
        "name": meta['layer_name_prefix'],
        "activeSelf": True,
        "color": color_hex,
        "children": [],
        "layerProperties": [_make_color_layer_property(color_hex)],
        "prefabId": meta['prefab_child']
    }

    parent_node = {
        "UUID": str(uuid.uuid4()),
        "name": ref,
        "activeSelf": True,
        "color": color_hex,
        "children": [child_node],
        "layerProperties": [
            {
                "$type": "https://netherlands3d.eu/schemas/projects/layers/properties/Url",
                "url": ref
            },
            _make_color_layer_property_empty(color_hex)
        ],
        "prefabId": meta['prefab_parent']
    }

    return parent_node


def _layer_to_geojson(layer, target_crs):
    """
    Export a QGIS vector layer to a GeoJSON string in the target CRS.
    Returns a dict (parsed GeoJSON).
    """
    source_crs = layer.crs()
    transform = QgsCoordinateTransform(source_crs, target_crs, QgsProject.instance())
    needs_transform = source_crs != target_crs

    features = []
    for feature in layer.getFeatures():
        geom = feature.geometry()
        if geom.isNull():
            continue

        if needs_transform:
            geom.transform(transform)

        # Properties: all attributes
        props = {}
        for field in layer.fields():
            val = feature[field.name()]
            # JSON-serialisable conversion
            if hasattr(val, 'isnull') or val is None:
                props[field.name()] = None
            elif isinstance(val, (int, float, bool, str)):
                props[field.name()] = val
            else:
                props[field.name()] = str(val)

        geom_json = json.loads(geom.asJson())

        features.append({
            "type": "Feature",
            "properties": props,
            "geometry": geom_json
        })

    return {
        "type": "FeatureCollection",
        "name": layer.name(),
        "crs": {
            "type": "name",
            "properties": {"name": "urn:ogc:def:crs:EPSG::28992"}
        },
        "features": features
    }


class NL3DExporter(QObject):
    """Exports QGIS layers to .nl3d format."""

    progress_updated = pyqtSignal(int, str)

    def export(self, export_items, output_path):
        """
        Build and write a .nl3d file.

        :param export_items: list of (QgsVectorLayer, export_as_label, color_hex)
        :param output_path: path to output .nl3d file
        """
        target_crs = QgsCoordinateReferenceSystem('EPSG:28992')

        # Group layers by export type; last write wins per filename type
        # (so multiple layers of the same type merge into one GeoJSON)
        geojson_data = {}   # filename -> merged feature list + metadata
        layer_nodes = []    # for project.json rootLayer.children

        total = len(export_items)

        for idx, (layer, export_as, color_hex) in enumerate(export_items):
            self.progress_updated.emit(idx, f'Exporteren: {layer.name()}…')

            meta = EXPORT_TYPE_MAP[export_as]
            filename = meta['filename']

            # Convert layer to GeoJSON
            gj = _layer_to_geojson(layer, target_crs)

            if filename not in geojson_data:
                geojson_data[filename] = {
                    'type': 'FeatureCollection',
                    'name': meta['geojson_name'],
                    'crs': gj['crs'],
                    'features': []
                }
            geojson_data[filename]['features'].extend(gj['features'])

            # Build layer tree node for this layer
            node = _build_layer_node(layer.name(), export_as, color_hex, filename)
            layer_nodes.append(node)

        # Build project.json
        self.progress_updated.emit(total, 'Bouwen van project.json…')

        now = datetime.now()
        timestamp = now.strftime('%Y%m%d%H%M%S')
        iso_dt = now.strftime('%Y-%m-%dT%H:%M:%S+01:00')

        # Compute a camera position from the extent of exported layers
        camera_pos = self._estimate_camera_position(export_items)

        project_json = {
            "Version": 2,
            "SavedTimestamp": timestamp,
            "UUID": str(uuid.uuid4()),
            "CameraRotation": [59.999996185302734, 0.0, 0.0],
            "UseCurrentTime": False,
            "functionalities": DEFAULT_FUNCTIONALITIES,
            "rootLayer": {
                "UUID": "81797d29-517a-48c8-8733-5dbe7d351dc3",
                "name": "RootLayer",
                "activeSelf": True,
                "color": "#569FE3FF",
                "children": layer_nodes + DEFAULT_BASE_LAYERS,
                "layerProperties": [],
                "prefabId": None
            },
            "CameraPosition": camera_pos,
            "CurrentDateTime": iso_dt,
            "name": "ProjectData",
            "hideFlags": "None"
        }

        # Write .nl3d zip archive
        self.progress_updated.emit(total, 'Schrijven naar schijf…')
        with zipfile.ZipFile(output_path, 'w', zipfile.ZIP_DEFLATED) as zf:
            # project.json
            zf.writestr(
                'project.json',
                json.dumps(project_json, ensure_ascii=False, indent=2)
            )
            # GeoJSON files
            for filename, gj in geojson_data.items():
                zf.writestr(
                    filename,
                    json.dumps(gj, ensure_ascii=False)
                )

            # If some types were not used, write empty placeholders so the
            # nl3d viewer can still open the file without missing-file errors.
            for export_as, meta in EXPORT_TYPE_MAP.items():
                fn = meta['filename']
                if fn not in geojson_data:
                    empty_gj = {
                        "type": "FeatureCollection",
                        "name": meta['geojson_name'],
                        "crs": {
                            "type": "name",
                            "properties": {"name": "urn:ogc:def:crs:EPSG::28992"}
                        },
                        "features": []
                    }
                    zf.writestr(fn, json.dumps(empty_gj, ensure_ascii=False))

        self.progress_updated.emit(total + 1, 'Klaar!')

    def _estimate_camera_position(self, export_items):
        """
        Estimate a sensible camera position from the bounding box of all exported layers.
        Returns [x, y, z] in RD New (EPSG:28992).
        Falls back to Amsterdam centre if no extent can be determined.
        """
        target_crs = QgsCoordinateReferenceSystem('EPSG:28992')
        xmin, ymin, xmax, ymax = None, None, None, None

        for layer, _, _ in export_items:
            source_crs = layer.crs()
            transform = QgsCoordinateTransform(source_crs, target_crs, QgsProject.instance())
            try:
                ext = layer.extent()
                if ext.isNull() or ext.isEmpty():
                    continue
                ext_rd = transform.transformBoundingBox(ext)
                if xmin is None:
                    xmin, ymin, xmax, ymax = ext_rd.xMinimum(), ext_rd.yMinimum(), ext_rd.xMaximum(), ext_rd.yMaximum()
                else:
                    xmin = min(xmin, ext_rd.xMinimum())
                    ymin = min(ymin, ext_rd.yMinimum())
                    xmax = max(xmax, ext_rd.xMaximum())
                    ymax = max(ymax, ext_rd.yMaximum())
            except Exception:
                pass

        if xmin is None:
            # Fallback: Amsterdam centre in RD New
            return [121947.33, 487840.32, 699.53]

        cx = (xmin + xmax) / 2.0
        cy = (ymin + ymax) / 2.0
        # Move camera south so we're looking at the centre, and up high enough
        spread = max(xmax - xmin, ymax - ymin)
        cam_y = cy - spread * 0.4
        cam_z = max(spread * 0.7, 300.0)

        return [cx, cam_y, cam_z]
