# -*- coding: utf-8 -*-
"""
2NL3D Plugin - Main plugin entry point
"""
import os
from qgis.PyQt.QtWidgets import QAction, QMessageBox
from qgis.PyQt.QtGui import QIcon
from qgis.core import QgsProject


class NL3DExportPlugin:
    """Main plugin class registered with QGIS."""

    def __init__(self, iface):
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)
        self.action = None
        self.dialog = None

    def initGui(self):
        """Create the menu entry and toolbar icon."""
        icon_path = os.path.join(self.plugin_dir, 'icon.png')
        icon = QIcon(icon_path) if os.path.exists(icon_path) else QIcon()

        self.action = QAction(icon, 'Exporteer naar .nl3d…', self.iface.mainWindow())
        self.action.setStatusTip('Exporteer QGIS lagen naar Netherlands3D (.nl3d) formaat')
        self.action.triggered.connect(self.run)

        # Add to Plugins menu and toolbar
        self.iface.addPluginToMenu('2NL3D', self.action)
        self.iface.addToolBarIcon(self.action)

    def unload(self):
        """Remove the plugin menu item and toolbar icon."""
        self.iface.removePluginMenu('2NL3D', self.action)
        self.iface.removeToolBarIcon(self.action)

    def run(self):
        """Open the export dialog."""
        from .dialog import NL3DExportDialog
        layers = QgsProject.instance().mapLayers().values()
        vector_layers = [l for l in layers if l.type() == l.VectorLayer]

        if not vector_layers:
            QMessageBox.warning(
                self.iface.mainWindow(),
                '2NL3D',
                'Er zijn geen vectorlagen geladen in het project.\n\n'
                'Laad eerst één of meer lagen (punten, lijnen of vlakken) om te exporteren.'
            )
            return

        dialog = NL3DExportDialog(self.iface, self.iface.mainWindow())
        dialog.exec_()
